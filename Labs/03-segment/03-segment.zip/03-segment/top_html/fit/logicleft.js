function showLogicLeft() { parent.leftnav.showLogicLeft(); }
